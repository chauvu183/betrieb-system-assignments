package schereSteinPapier;

/**
 * <p>Spielerentscheidung.</p>
 */
enum PlayerChoise {
    /**
     * <p>Scheere.</p>
     */
    SCHERE,

    /**
     * <p>Stein.</p>
     */
    STEIN,

    /**
     * <p>Papier.</p>
     */
    PAPIER
}
